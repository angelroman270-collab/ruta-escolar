import type { Metadata, Viewport } from "next"
import { Geist } from "next/font/google"
import { RegisterSW } from "@/components/register-sw"
import "./globals.css"

const geist = Geist({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "RutaEscolar - Transporte Escolar",
  description: "App de gestion de transporte escolar. Controla rutas, alumnos y notificaciones por WhatsApp y SMS.",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "RutaEscolar",
  },
  icons: {
    icon: "/icon-192.jpg",
    apple: "/icon-512.jpg",
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0a1628",
  viewportFit: "cover",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={geist.className}>
      <body className="font-sans antialiased overflow-hidden">
        {children}
        <RegisterSW />
      </body>
    </html>
  )
}
